# Bharat Electronics Limited Website

## Project Overview
This project is a multi-page informational website developed for Bharat Electronics Limited (BEL), focusing on digital security solutions such as SSL certificates, SMIME certificates, digital signature registration, and related resources. The website provides users with detailed product information, registration capabilities, contact options, and support resources.

## Project Structure
- `index.html`: Homepage with hero section, navigation menus with dropdowns, and footer with contact and newsletter subscription.
- `contact.html`: Contact page with a form for user inquiries.
- `faq.html`: Frequently Asked Questions page.
- `register.html`: Registration page for digital signature purchase with tabbed content and options.
- `ssl-certificates.html`: Details SSL certificate products with pricing and purchase options.
- `smime-certificates.html`: Details SMIME certificate products with features and pricing.
- `serve-local.js`: JavaScript file for local server or client-side functionality.
- Images: Includes `route map.jpeg` (homepage image) and `cyb.webp` (background image used on multiple pages).

## Key Features
- Responsive navigation with dropdown menus for easy access to various sections.
- Background images with gradient overlays for enhanced visual appeal.
- Interactive forms with client-side validation and user feedback.
- Product information presented in card layouts with pricing and purchase options.
- Language selection dropdown supporting English and Kannada.
- Newsletter subscription integrated in the footer.

## Technologies Used
- HTML5 and CSS3 for structure and styling.
- JavaScript for interactivity including dropdown toggling and form handling.
- SVG icons for scalable UI elements.
- Responsive design principles for cross-device compatibility.

## Implementation Details
- Background images applied with gradient overlays on homepage and key pages.
- Dropdown menus toggled via JavaScript by adding/removing active classes.
- Fixed header with transparent background for consistent navigation visibility.
- Forms include basic validation and alert-based user feedback.

## How to Run
Open the `index.html` file in a modern web browser to view the homepage. Navigate to other pages via the menu links.

## Recommendations for Improvement
- Externalize CSS and JavaScript into separate files for better maintainability.
- Enhance accessibility with ARIA roles and keyboard navigation support.
- Implement server-side form handling for contact and registration.
- Optimize images for faster loading.
- Add automated tests for interactive components.

## Author
Anvitha Karanth, Nihitha H R 


